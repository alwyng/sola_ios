function getPicture(){
	navigator.camera.getPicture(function(){}, function(){});
}
    
